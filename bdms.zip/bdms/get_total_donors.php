<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "project"; // use your actual DB name

// Connect to DB
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo "DB error";
    exit;
}

// Fetch total donors
$sql = "SELECT COUNT(*) as total FROM Donor";
$result = $conn->query($sql);

if ($result) {
    $row = $result->fetch_assoc();
    echo $row['total'];
} else {
    echo "0";
}

$conn->close();
?>
