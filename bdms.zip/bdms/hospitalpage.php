<?php
// Database connection
$host = "localhost";
$user = "root";
$password = "";
$database = "project"; // Change if needed

$conn = new mysqli($host, $user, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("<div class='error'>Connection failed: " . $conn->connect_error . "</div>");
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name       = $_POST["name"];
    $address    = $_POST["address"];
    $phone      = $_POST["phone"];
    $email      = $_POST["email"];
    $regNumber  = $_POST["regNumber"];
    $type       = $_POST["type"];

    $stmt = $conn->prepare("INSERT INTO Hospital (Name, Address, PhoneNumber, Email, RegistrationNumber, Type) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $name, $address, $phone, $email, $regNumber, $type);

    if ($stmt->execute()) {
        echo "<div class='success'>Hospital registered successfully!</div>";
    } else {
        echo "<div class='error'>Error: " . $stmt->error . "</div>";
    }

    $stmt->close();
    $conn->close();
}
?>
