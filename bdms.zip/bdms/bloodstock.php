<?php
// Replace with your actual database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form values
$bloodBankID = $_POST['bloodBankID'];
$bloodType = $_POST['bloodType'];
$units = $_POST['UnitsAvailable'];
$lastUpdated = $_POST['lastUpdated'];
$expiryDate = $_POST['expiryDate'];
$storage = $_POST['StorageLocation'];
$status = $_POST['status'];

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO bloodstock (bloodBankID, bloodType, UnitsAvailable, lastUpdated, expiryDate, StorageLocation, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("isissss", $bloodBankID, $bloodType, $units, $lastUpdated, $expiryDate, $storage, $status);
if ($stmt->execute()) {
    echo "<h2>Blood stock entry added successfully.</h2>";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
