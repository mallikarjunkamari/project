<?php
// Database connection settings
$servername = "localhost";
$username = "root";
$password = ""; // Update if you use a different password
$dbname = "project"; // Replace with your actual database name

// Create the database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if connection failed
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Collect and sanitize form data
$patientID = $_POST['patientID'] ?? null;
$hospitalID = $_POST['hospitalID'] ?? null;
$stockID = $_POST['stockID'] ?? null;
$unitsUsed = $_POST['unitsUsed'] ?? null;
$dateOfTransfusion = $_POST['dateOfTransfusion'] ?? null;
$status = $_POST['status'] ?? 'Pending'; // default fallback

// Prepare the SQL insert statement
$sql = "INSERT INTO patientbloodtransaction 
        (PatientID, HospitalID, StockID, UnitsUsed, DateOfTransfusion, Status)
        VALUES (?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

// Bind parameters (ii i i s s = 3 integers, 1 int, 1 date string, 1 status string)
$stmt->bind_param("iiiiss", $patientID, $hospitalID, $stockID, $unitsUsed, $dateOfTransfusion, $status);

// Execute and handle the result
if ($stmt->execute()) {
    echo "<h2>Transaction submitted successfully!</h2>";
} else {
    echo "<h2>Error: " . htmlspecialchars($stmt->error) . "</h2>";
}

// Clean up
$stmt->close();
$conn->close();
?>
