<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "project"; // Change to your database name

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    http_response_code(500);
    echo "DB Error";
    exit;
}

$sql = "SELECT SUM(UnitsAvailable) AS total_units FROM BloodStock";
$result = $conn->query($sql);

if ($result && $row = $result->fetch_assoc()) {
    echo $row['total_units'] ?? 0;
} else {
    echo "0";
}

$conn->close();
?>
