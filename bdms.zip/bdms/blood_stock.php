<?php
// Database connection
$host = "localhost";
$user = "root";
$password = "";
$db = "bloodbank";

$conn = new mysqli($host, $user, $password, $db);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$result = $conn->query("SELECT * FROM bloodbank ORDER BY BloodType ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Blood Stock - Blood Bank</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f5f5f5;
      margin: 0;
      padding: 20px;
    }

    .container {
      max-width: 700px;
      margin: 40px auto;
      background-color: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #c0392b;
      margin-bottom: 30px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    th, td {
      padding: 14px;
      text-align: center;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: #c0392b;
      color: white;
    }

    tr:hover {
      background-color: #f1f1f1;
    }

    @media (max-width: 600px) {
      .container {
        padding: 20px;
      }

      th, td {
        padding: 10px;
      }
    }
  </style>
</head>
<body>

  <div class="container">
    <h2>Current Blood Stock</h2>
    <table>
      <thead>
        <tr>
          <th>Blood Group</th>
          <th>Units Available</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()) { ?>
          <tr>
            <td><?php echo $row['blood_type']; ?></td>
            <td><?php echo $row['units_available']; ?></td>
          </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>

</body>
</html>

<?php
$conn->close();
?>
