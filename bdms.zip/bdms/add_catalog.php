<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$database = "project"; // Change this to your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Only handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect data safely using the real_escape_string to prevent SQL injection
    $bloodType = $conn->real_escape_string($_POST['BloodType']);
    $availabilityStatus = $conn->real_escape_string($_POST['AvailabilityStatus']);
    $lastDonationDate = !empty($_POST['LastDonationDate']) ? $_POST['LastDonationDate'] : NULL;
    $healthRemarks = isset($_POST['HealthRemarks']) ? $conn->real_escape_string($_POST['HealthRemarks']) : NULL;

    // Handle IsActive checkbox (if checked, it's 'Active'; otherwise, 'Inactive')
    $isActive = isset($_POST['IsActive']) ? 1 : 0;

    // Prepare the SQL query to insert the data into the DonorCatalog table
    $sql = "INSERT INTO DonorCatalog (BloodType, AvailabilityStatus, LastDonationDate, HealthRemarks, IsActive) 
            VALUES ('$bloodType', '$availabilityStatus', " . ($lastDonationDate ? "'$lastDonationDate'" : "NULL") . ", " . 
            ($healthRemarks ? "'$healthRemarks'" : "NULL") . ", $isActive)";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        // Success message
        echo "<h2>Catalog Entry Added Successfully!</h2>";
        echo "<p><a href='donor_catalog.html'>Add Another Entry</a></p>";
    } else {
        // Error handling
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    // Handle invalid access (e.g., if someone tries to directly access this script without submitting the form)
    echo "<h2>Invalid Access</h2>";
    echo "<p>Please <a href='donor_catalog.html'>fill the catalog form</a>.</p>";
}

// Close the connection
$conn->close();
?>
