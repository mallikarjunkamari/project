<?php
// Database connection
$host = "localhost";
$user = "root";          // Default for XAMPP
$password = "";          // Default is blank for XAMPP
$dbname = "project";  // Your database name

// Create connection
$conn = new mysqli($host, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get POST data from the form
$BloodBankID = $_POST['BloodBankID'];
$Name = $_POST['Name'];
$Location = $_POST['Location'];
$ContactNumber = $_POST['ContactNumber'];
$OperatingHours = $_POST['OperatingHours'];
$AssociatedHospitalID = $_POST['AssociatedHospitalID'];
$LicenseNumber = $_POST['LicenseNumber'];

// Prepare and bind statement to avoid SQL injection
$stmt = $conn->prepare("INSERT INTO BloodBank (BloodBankID, Name, Location, ContactNumber, OperatingHours, AssociatedHospitalID, LicenseNumber) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("issssis", $BloodBankID, $Name, $Location, $ContactNumber, $OperatingHours, $AssociatedHospitalID, $LicenseNumber);

// Execute the query
if ($stmt->execute()) {
  echo "<h3 style='text-align:center;color:green;'>Blood bank added successfully!</h3>";
} else {
  echo "<h3 style='text-align:center;color:red;'>Error: " . $stmt->error . "</h3>";
}

// Close connection
$stmt->close();
$conn->close();
?>

