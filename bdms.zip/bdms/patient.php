<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "project"; // your DB name

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstName = $_POST["firstName"];
    $lastName = $_POST["lastName"];
    $dob = $_POST["dob"];
    $gender = $_POST["gender"];
    $bloodType = $_POST["bloodType"];
    $contact = $_POST["contact"];
    $address = $_POST["address"];
    $hospitalId = $_POST["hospitalId"];
    $medicalRecord = $_POST["medicalRecord"];
    $bloodRequired = $_POST["bloodRequired"];
    $unitsRequired = !empty($_POST["unitsRequired"]) ? $_POST["unitsRequired"] : null;
    $dateRequested = !empty($_POST["dateRequested"]) ? $_POST["dateRequested"] : null;
    $status = $_POST["status"];

    $stmt = $conn->prepare("INSERT INTO Patient (
        FirstName, LastName, DateOfBirth, Gender, BloodType,
        ContactNumber, Address, HospitalID, MedicalRecordNumber,
        BloodRequired, UnitsRequired, DateRequested, Status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $stmt->bind_param(
        "sssssssississ",
        $firstName,
        $lastName,
        $dob,
        $gender,
        $bloodType,
        $contact,
        $address,
        $hospitalId,
        $medicalRecord,
        $bloodRequired,
        $unitsRequired,
        $dateRequested,
        $status
    );

    if ($stmt->execute()) {
        echo "Patient registered successfully.";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
