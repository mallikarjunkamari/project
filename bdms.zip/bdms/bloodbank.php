<?php
header('Content-Type: application/json');

$host = "localhost";
$user = "root";
$password = "";
$database = "project"; // Make sure this DB exists

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed."]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $location = $_POST["location"];
    $phone = $_POST["phone"];
    $email = $_POST["email"];
    $hours = $_POST["hours"];
    $license = $_POST["license"];
    $hospitalId = $_POST["hospitalId"];

    $stmt = $conn->prepare("INSERT INTO BloodBank (Name, Location, PhoneNumber, Email, OperatingHours, LicenseNumber, HospitalID) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssi", $name, $location, $phone, $email, $hours, $license, $hospitalId);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Blood bank registered successfully!"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Registration failed or already exists."]);
    }

    $stmt->close();
    $conn->close();
}
?>
