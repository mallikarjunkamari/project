<?php
// DB Connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    echo "Database connection failed!";
    exit;
}

// Collect and sanitize POST data
$FirstName = $_POST['FirstName'] ?? '';
$LastName = $_POST['LastName'] ?? '';
$DateOfBirth = $_POST['DateOfBirth'] ?? '';
$Gender = $_POST['Gender'] ?? '';
$BloodType = $_POST['BloodType'] ?? '';
$ContactNumber = $_POST['ContactNumber'] ?? '';
$Email = $_POST['Email'] ?? '';
$Address = $_POST['Address'] ?? '';
$LastDonationDate = $_POST['LastDonationDate'] ?? '';
$EligibilityStatus = $_POST['EligibilityStatus'] ?? '';
$MedicalConditions = $_POST['MedicalConditions'] ?? NULL;

// Step 1: Insert into DonorCatalog
$insertCatalog = $conn->prepare("INSERT INTO DonorCatalog (BloodType, AvailabilityStatus, LastDonationDate, HealthRemarks, IsActive)
                                 VALUES (?, 'Available', ?, NULL, 1)");
$insertCatalog->bind_param("ss", $BloodType, $LastDonationDate);

if ($insertCatalog->execute()) {
    $CatalogID = $insertCatalog->insert_id;

    // Step 2: Insert into Donor
    $insertDonor = $conn->prepare("INSERT INTO Donor 
      (FirstName, LastName, DateOfBirth, Gender, BloodType, ContactNumber, Email, Address, LastDonationDate, EligibilityStatus, MedicalConditions, CatalogID) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    $insertDonor->bind_param("sssssssssssi", $FirstName, $LastName, $DateOfBirth, $Gender, $BloodType, $ContactNumber, $Email, $Address, $LastDonationDate, $EligibilityStatus, $MedicalConditions, $CatalogID);

    if ($insertDonor->execute()) {
        echo "<span style='color:green;'>✅ Donor added successfully!</span>";
    } else {
        echo "<span style='color:red;'>❌ Error adding donor: " . $insertDonor->error . "</span>";
    }

    $insertDonor->close();
} else {
    echo "<span style='color:red;'>❌ Error in DonorCatalog: " . $insertCatalog->error . "</span>";
}

$insertCatalog->close();
$conn->close();
?>
