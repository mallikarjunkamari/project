<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Query to get total donors
$sql_donors = "SELECT COUNT(*) AS total_donors FROM donor";
$result_donors = $conn->query($sql_donors);
$totalDonors = ($result_donors->num_rows > 0) ? $result_donors->fetch_assoc()['total_donors'] : 0;

// Query to get total available units
$sql_units = "SELECT SUM(units) AS total_units FROM donor";
$result_units = $conn->query($sql_units);
$totalUnits = ($result_units->num_rows > 0) ? $result_units->fetch_assoc()['total_units'] : 0;

// Query to get upcoming appointments
$sql_appointments = "SELECT COUNT(*) AS upcoming_appointments FROM appointments WHERE appointment_date >= CURDATE()";
$result_appointments = $conn->query($sql_appointments);
$upcomingAppointments = ($result_appointments->num_rows > 0) ? $result_appointments->fetch_assoc()['upcoming_appointments'] : 0;

// Query to get pending requests
$sql_requests = "SELECT COUNT(*) AS pending_requests FROM requests WHERE status = 'Pending'";
$result_requests = $conn->query($sql_requests);
$pendingRequests = ($result_requests->num_rows > 0) ? $result_requests->fetch_assoc()['pending_requests'] : 0;

// Close connection
$conn->close();
?>
