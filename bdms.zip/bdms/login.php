<?php
// Hardcoded credentials (in real-world apps, use a database with hashed passwords)
$valid_username = "mallikarjun";
$valid_password = "Bec@bgk";

// Get the submitted values
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

// Check credentials
if ($username === $valid_username && $password === $valid_password) {
    // Optional: start session
    session_start();
    $_SESSION['username'] = $username;

    // Redirect to dashboard
    header("Location: dashboard.html");
    exit;
} else {
    echo "<h2 style='color:red; text-align:center;'>Invalid username or password</h2>";
    echo "<p style='text-align:center;'><a href='login.html'>Try again</a></p>";
}
?>
