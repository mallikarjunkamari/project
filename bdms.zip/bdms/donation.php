<?php
// Database connection configuration
$servername = "localhost";
$username = "root";
$password = ""; // Replace with your actual password
$dbname = "project"; // Replace with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Collect form data safely
$donorID = $_POST['DonorID'] ?? null;
$catalogID = $_POST['CatalogID'] ?? null;
$stockID = $_POST['StockID'] ?? null;
$donationDate = $_POST['DonationDate'] ?? null;
$unitsDonated = $_POST['UnitsDonated'] ?? null;
$verifiedBy = $_POST['VerifiedBy'] ?? null;
$remarks = $_POST['Remarks'] ?? null;

// Prepare SQL insert statement
$sql = "INSERT INTO Donation (DonorID, CatalogID, StockID, DonationDate, UnitsDonated, VerifiedBy, Remarks) 
        VALUES (?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

// Bind parameters: iiisiss => int, int, int, string, int, string, string
$stmt->bind_param("iiisiss", $donorID, $catalogID, $stockID, $donationDate, $unitsDonated, $verifiedBy, $remarks);

// Execute the statement and handle the result
if ($stmt->execute()) {
    echo "<h2>Donation record submitted successfully!</h2>";
} else {
    echo "<h2>Error: " . htmlspecialchars($stmt->error) . "</h2>";
}

// Close statement and connection
$stmt->close();
$conn->close();
?>
